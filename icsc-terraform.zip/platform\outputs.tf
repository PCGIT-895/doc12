output "allowed_locations_assignment_id" {
  value = module.policy_guardrails.allowed_locations_assignment_id
}

output "storage_secure_transfer_assignment_id" {
  value = module.policy_guardrails.storage_secure_transfer_assignment_id
}

output "storage_min_tls_assignment_id" {
  value = module.policy_guardrails.storage_min_tls_assignment_id
}
