subscription_id = "16eaf4c0-10f5-40ad-8cc6-d93f09632ae1"

# Already default to Milan / Frankfurt - only need to touch these if
# Azure's internal naming changes.
# primary_location = "italynorth"
# dr_location      = "germanywestcentral"
