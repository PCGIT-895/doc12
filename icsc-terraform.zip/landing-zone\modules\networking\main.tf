# ---------------------------------------------------------------------------
# Network topology per the client's official document:
# "ICSC - Azure Network Landing Zone" (HLD, v1.0, June 2026).
#
# 5 VNets in a star topology around the Hub, instead of a plain hub+spoke:
#   hub  -> Perimeter firewall (Fortinet FortiGate NVA, Active-Active HA
#           cluster) + Azure VPN Gateway (S2S to Retelit/Cedacri/ICSC
#           sites/partner).
#   ad   -> Domain Controllers (extension of the on-premises AD), internal
#           DNS resolver (uses 168.63.129.16 as forwarder, per the HLD).
#   dmz  -> services exposed to the public network (reverse proxy, ADFS).
#   farm -> "Server Farm": application servers migrated lift-and-shift,
#           segmented into App/Backend subnets.
#   vdi  -> "VDI Farm": reserved for Azure Virtual Desktop. The HLD
#           pre-provisions two subnets (shared/dedicated host pool) but the
#           actual AVD deployment is out of scope for this module (see
#           README, point 6 - "does NOT include AVD").
#
# IMPORTANT NOTE (Disaster Recovery in "cold site" mode):
# The HLD states that, for Server Farm and VDI Farm, Production and DR
# SHARE the same address space (DR servers keep their IP unchanged,
# protected by Azure Site Recovery). Therefore:
#   - farm_cidr and vdi_cidr must NOT be peered between Milan and Frankfurt
#     (Azure rejects peering between VNets with overlapping address
#     spaces). Replication happens at the VM level via ASR, not the
#     network level.
#   - Only Hub, AD and DMZ have a distinct CIDR per region and are
#     cross-peered between Milan<->Frankfurt (see landing-zone/main.tf).
# ---------------------------------------------------------------------------

locals {
  hub_name  = "vnet-icsc-hub-${var.environment}-${var.region_code}"
  ad_name   = "vnet-icsc-ad-${var.environment}-${var.region_code}"
  dmz_name  = "vnet-icsc-dmz-${var.environment}-${var.region_code}"
  farm_name = "vnet-icsc-farm-${var.environment}-${var.region_code}"
  vdi_name  = "vnet-icsc-vdi-${var.environment}-${var.region_code}"
}

# ---------------------------------------------------------------------------
# HUB VNet - Perimeter firewall (FortiGate NVA) + VPN Gateway
# ---------------------------------------------------------------------------

resource "azurerm_virtual_network" "hub" {
  name                = local.hub_name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.hub_cidr]
  tags                = var.tags
}

# NOTE: the reserved name "AzureFirewallSubnet" is NOT used because the
# project's firewall is a third-party NVA (Fortinet FortiGate, provisioned
# from the Azure Marketplace - see RACI Matrix, task "Provisioning Cluster
# FortiGate from Marketplace"), not the native Azure Firewall service. That
# reserved subnet is exclusive to the managed service.
resource "azurerm_subnet" "fw_public" {
  name                 = "snet-fw-public-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = [cidrsubnet(var.hub_cidr, 4, 0)]
}

resource "azurerm_subnet" "fw_private" {
  name                 = "snet-fw-private-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = [cidrsubnet(var.hub_cidr, 4, 1)]
}

# Azure's mandatory reserved name for the VPN Gateway.
resource "azurerm_subnet" "gateway" {
  name                 = "GatewaySubnet"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = [cidrsubnet(var.hub_cidr, 3, 7)]
}

# ---------------------------------------------------------------------------
# Active Directory VNet - Domain Controllers
# ---------------------------------------------------------------------------

resource "azurerm_virtual_network" "ad" {
  name                = local.ad_name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.ad_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "dc" {
  name                 = "snet-dc-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.ad.name
  address_prefixes     = [cidrsubnet(var.ad_cidr, 3, 0)]
}

resource "azurerm_network_security_group" "dc" {
  name                = "nsg-dc-${var.environment}-${var.region_code}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_subnet_network_security_group_association" "dc" {
  subnet_id                 = azurerm_subnet.dc.id
  network_security_group_id = azurerm_network_security_group.dc.id
}

# ---------------------------------------------------------------------------
# DMZ VNet - services exposed to the Internet (reverse proxy, ADFS, ...)
# ---------------------------------------------------------------------------

resource "azurerm_virtual_network" "dmz" {
  name                = local.dmz_name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.dmz_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "dmz" {
  name                 = "snet-dmz-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.dmz.name
  address_prefixes     = [cidrsubnet(var.dmz_cidr, 3, 0)]
}

# NOTE: detailed rules (exact sources/ports for ADFS/reverse proxy) are
# pending validation against the client's network access census before the
# first apply.
resource "azurerm_network_security_group" "dmz" {
  name                = "nsg-dmz-${var.environment}-${var.region_code}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "allow-https-inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }
}

resource "azurerm_subnet_network_security_group_association" "dmz" {
  subnet_id                 = azurerm_subnet.dmz.id
  network_security_group_id = azurerm_network_security_group.dmz.id
}

# ---------------------------------------------------------------------------
# Server Farm VNet - migrated application workloads (lift-and-shift)
# ---------------------------------------------------------------------------

resource "azurerm_virtual_network" "farm" {
  name                = local.farm_name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.farm_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "farm_app" {
  name                 = "snet-farm-app-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.farm.name
  address_prefixes     = [cidrsubnet(var.farm_cidr, 5, 0)]
}

resource "azurerm_subnet" "farm_backend" {
  name                 = "snet-farm-backend-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.farm.name
  address_prefixes     = [cidrsubnet(var.farm_cidr, 5, 8)]
}

resource "azurerm_subnet" "farm_private_endpoint" {
  name                 = "snet-farm-pe-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.farm.name
  address_prefixes     = [cidrsubnet(var.farm_cidr, 5, 31)]

  private_endpoint_network_policies = "Disabled"
}

resource "azurerm_network_security_group" "farm_app" {
  name                = "nsg-farm-app-${var.environment}-${var.region_code}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_subnet_network_security_group_association" "farm_app" {
  subnet_id                 = azurerm_subnet.farm_app.id
  network_security_group_id = azurerm_network_security_group.farm_app.id
}

resource "azurerm_network_security_group" "farm_backend" {
  name                = "nsg-farm-backend-${var.environment}-${var.region_code}"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

resource "azurerm_subnet_network_security_group_association" "farm_backend" {
  subnet_id                 = azurerm_subnet.farm_backend.id
  network_security_group_id = azurerm_network_security_group.farm_backend.id
}

# ---------------------------------------------------------------------------
# VDI Farm VNet - reserved for Azure Virtual Desktop (host pools).
# Network only: deploying the host pools / session hosts is out of scope
# for this module (README, point 6).
# ---------------------------------------------------------------------------

resource "azurerm_virtual_network" "vdi" {
  name                = local.vdi_name
  location            = var.location
  resource_group_name = var.resource_group_name
  address_space       = [var.vdi_cidr]
  tags                = var.tags
}

resource "azurerm_subnet" "vdi_shared" {
  name                 = "snet-vdi-shared-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.vdi.name
  address_prefixes     = [cidrsubnet(var.vdi_cidr, 1, 0)]
}

resource "azurerm_subnet" "vdi_dedicated" {
  name                 = "snet-vdi-dedicated-${var.environment}-${var.region_code}"
  resource_group_name  = var.resource_group_name
  virtual_network_name = azurerm_virtual_network.vdi.name
  address_prefixes     = [cidrsubnet(var.vdi_cidr, 2, 2)]
}

# ---------------------------------------------------------------------------
# Star peering WITHIN the same region: Hub <-> AD/DMZ/Farm/VDI
# ---------------------------------------------------------------------------

locals {
  spokes = {
    ad   = azurerm_virtual_network.ad
    dmz  = azurerm_virtual_network.dmz
    farm = azurerm_virtual_network.farm
    vdi  = azurerm_virtual_network.vdi
  }
}

resource "azurerm_virtual_network_peering" "hub_to_spoke" {
  for_each                     = local.spokes
  name                         = "peer-hub-to-${each.key}-${var.environment}-${var.region_code}"
  resource_group_name          = var.resource_group_name
  virtual_network_name         = azurerm_virtual_network.hub.name
  remote_virtual_network_id    = each.value.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = true
  use_remote_gateways          = false
}

resource "azurerm_virtual_network_peering" "spoke_to_hub" {
  for_each                     = local.spokes
  name                         = "peer-${each.key}-to-hub-${var.environment}-${var.region_code}"
  resource_group_name          = var.resource_group_name
  virtual_network_name         = each.value.name
  remote_virtual_network_id    = azurerm_virtual_network.hub.id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = false
}
