# IMPORTANT NOTE: the policy_definition_id values below are the usual
# public GUIDs for these built-in Azure policies. Before the first
# `terraform apply`, verify them against the real subscription with:
#
#   az policy definition list --query "[?displayName=='Allowed locations']"
#   az policy definition list --query "[?displayName=='Secure transfer to storage accounts should be enabled']"
#   az policy definition list --query "[?contains(displayName, 'minimum TLS version')]"
#
# since Microsoft can version or replace built-in definitions.

locals {
  subscription_scope = "/subscriptions/${var.subscription_id}"
}

resource "azurerm_subscription_policy_assignment" "allowed_locations" {
  name                 = "icsc-allowed-locations"
  display_name         = "ICSC - Allowed locations (Italy North + Germany West Central)"
  subscription_id      = local.subscription_scope
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/e56962a6-4747-49cd-b67b-bf8b01975c4c"

  parameters = jsonencode({
    listOfAllowedLocations = {
      value = [var.primary_location, var.dr_location]
    }
  })
}

resource "azurerm_subscription_policy_assignment" "storage_secure_transfer" {
  name                 = "icsc-storage-secure-transfer"
  display_name         = "ICSC - Secure transfer (HTTPS) required on storage accounts"
  subscription_id      = local.subscription_scope
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/404c3081-a854-4457-ae30-26a93ef643f9"
}

resource "azurerm_subscription_policy_assignment" "storage_min_tls" {
  name                 = "icsc-storage-min-tls12"
  display_name         = "ICSC - Minimum TLS 1.2 on storage accounts"
  subscription_id      = local.subscription_scope
  policy_definition_id = "/providers/Microsoft.Authorization/policyDefinitions/fe83a0eb-a853-422d-aac2-1bffd182c5d0"

  parameters = jsonencode({
    minimumTlsVersion = {
      value = "TLS1_2"
    }
  })
}
