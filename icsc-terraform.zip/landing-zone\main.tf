# =============================================================================
# PRIMARY REGION - MILAN (Italy North)
# =============================================================================

module "rg_network_primary" {
  source   = "./modules/resource_group"
  name     = "rg-icsc-network-${var.environment}-${local.region_code_primary}"
  location = var.primary_location
  tags     = local.common_tags
}

module "rg_security_primary" {
  source   = "./modules/resource_group"
  name     = "rg-icsc-security-${var.environment}-${local.region_code_primary}"
  location = var.primary_location
  tags     = local.common_tags
}

module "rg_monitoring_primary" {
  source   = "./modules/resource_group"
  name     = "rg-icsc-monitoring-${var.environment}-${local.region_code_primary}"
  location = var.primary_location
  tags     = local.common_tags
}

module "rg_backup_primary" {
  source   = "./modules/resource_group"
  name     = "rg-icsc-backup-${var.environment}-${local.region_code_primary}"
  location = var.primary_location
  tags     = local.common_tags
}

module "networking_primary" {
  source              = "./modules/networking"
  environment         = var.environment
  region_code         = local.region_code_primary
  location            = var.primary_location
  resource_group_name = module.rg_network_primary.name
  hub_cidr            = var.hub_cidr_primary
  ad_cidr             = var.ad_cidr_primary
  dmz_cidr            = var.dmz_cidr_primary
  farm_cidr           = var.farm_cidr_primary
  vdi_cidr            = var.vdi_cidr_primary
  tags                = local.common_tags
}

module "security_primary" {
  source              = "./modules/security"
  environment         = var.environment
  region_code         = local.region_code_primary
  location            = var.primary_location
  resource_group_name = module.rg_security_primary.name
  tags                = local.common_tags
}

module "monitoring_primary" {
  source              = "./modules/monitoring"
  environment         = var.environment
  region_code         = local.region_code_primary
  location            = var.primary_location
  resource_group_name = module.rg_monitoring_primary.name
  tags                = local.common_tags
}

module "backup_primary" {
  source              = "./modules/backup"
  environment         = var.environment
  region_code         = local.region_code_primary
  location            = var.primary_location
  resource_group_name = module.rg_backup_primary.name
  tags                = local.common_tags
}

# ---------------------------------------------------------------------------
# Diagnostic settings -> Log Analytics (closes the TODO in modules/monitoring)
# ---------------------------------------------------------------------------

module "diagnostics_primary" {
  source            = "./modules/diagnostics"
  workspace_id      = module.monitoring_primary.workspace_id
  name_suffix       = "${var.environment}-${local.region_code_primary}"
  hub_vnet_id       = module.networking_primary.hub_vnet_id
  farm_vnet_id      = module.networking_primary.farm_vnet_id
  key_vault_id      = module.security_primary.key_vault_id
  has_key_vault     = true
  recovery_vault_id = module.backup_primary.vault_id
}

# =============================================================================
# DR REGION - FRANKFURT (Germany West Central) - only if enable_dr = true
# =============================================================================

module "rg_network_dr" {
  count    = var.enable_dr ? 1 : 0
  source   = "./modules/resource_group"
  name     = "rg-icsc-network-${var.environment}-${local.region_code_dr}"
  location = var.dr_location
  tags     = local.common_tags
}

module "rg_monitoring_dr" {
  count    = var.enable_dr ? 1 : 0
  source   = "./modules/resource_group"
  name     = "rg-icsc-monitoring-${var.environment}-${local.region_code_dr}"
  location = var.dr_location
  tags     = local.common_tags
}

module "rg_backup_dr" {
  count    = var.enable_dr ? 1 : 0
  source   = "./modules/resource_group"
  name     = "rg-icsc-backup-${var.environment}-${local.region_code_dr}"
  location = var.dr_location
  tags     = local.common_tags
}

module "networking_dr" {
  count               = var.enable_dr ? 1 : 0
  source              = "./modules/networking"
  environment         = var.environment
  region_code         = local.region_code_dr
  location            = var.dr_location
  resource_group_name = module.rg_network_dr[0].name
  hub_cidr            = var.hub_cidr_dr
  ad_cidr             = var.ad_cidr_dr
  dmz_cidr            = var.dmz_cidr_dr
  # "Cold site": Server Farm and VDI Farm in DR share the SAME address
  # space as Milan (see variables.tf and modules/networking/main.tf).
  # They are not peered with Milan for that reason.
  farm_cidr = var.farm_cidr_dr
  vdi_cidr  = var.vdi_cidr_dr
  tags      = local.common_tags
}

module "monitoring_dr" {
  count               = var.enable_dr ? 1 : 0
  source              = "./modules/monitoring"
  environment         = var.environment
  region_code         = local.region_code_dr
  location            = var.dr_location
  resource_group_name = module.rg_monitoring_dr[0].name
  tags                = local.common_tags
}

# The Frankfurt Recovery Services Vault is the one that would be used as the
# Azure Site Recovery (ASR) target from Milan, per the client's technical
# documentation ("Azure Site Recovery (ASR) in Frankfurt").
module "backup_dr" {
  count               = var.enable_dr ? 1 : 0
  source              = "./modules/backup"
  environment         = var.environment
  region_code         = local.region_code_dr
  location            = var.dr_location
  resource_group_name = module.rg_backup_dr[0].name
  tags                = local.common_tags
}

module "diagnostics_dr" {
  count             = var.enable_dr ? 1 : 0
  source            = "./modules/diagnostics"
  workspace_id      = module.monitoring_dr[0].workspace_id
  name_suffix       = "${var.environment}-${local.region_code_dr}"
  hub_vnet_id       = module.networking_dr[0].hub_vnet_id
  farm_vnet_id      = module.networking_dr[0].farm_vnet_id
  key_vault_id      = null
  has_key_vault     = false
  recovery_vault_id = module.backup_dr[0].vault_id
}

# =============================================================================
# HUB-TO-HUB CROSS PEERING (Milan <-> Frankfurt) for DR replication
#
# Only the Hub is peered between regions (Firewall/VPN/AD/DMZ have their
# own, distinct CIDR per region). Server Farm and VDI Farm are NOT peered
# cross-region because, in the "cold site" DR model, they share the same
# address space as Milan (see modules/networking/main.tf) and Azure does
# not support peering between VNets with overlapping ranges.
# =============================================================================

resource "azurerm_virtual_network_peering" "hub_primary_to_dr" {
  count                        = var.enable_dr ? 1 : 0
  name                         = "peer-hub-mi-to-hub-fr-${var.environment}"
  resource_group_name          = module.rg_network_primary.name
  virtual_network_name         = module.networking_primary.hub_vnet_name
  remote_virtual_network_id    = module.networking_dr[0].hub_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = false
}

resource "azurerm_virtual_network_peering" "hub_dr_to_primary" {
  count                        = var.enable_dr ? 1 : 0
  name                         = "peer-hub-fr-to-hub-mi-${var.environment}"
  resource_group_name          = module.rg_network_dr[0].name
  virtual_network_name         = module.networking_dr[0].hub_vnet_name
  remote_virtual_network_id    = module.networking_primary.hub_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
  allow_gateway_transit        = false
  use_remote_gateways          = false
}

# =============================================================================
# RBAC - real access separation between environments (see variables.tf)
# =============================================================================

locals {
  # Resource Group names for THIS environment (primary + DR if applicable),
  # recomputed here (instead of reading module.rg_*.id) on purpose: a
  # Resource Group's "id" does not exist until it is created, and a for_each
  # needs to know the full set of keys BEFORE apply. Using module.rg_*.id as
  # the for_each key would fail on the first deployment with "Invalid
  # for_each argument" (it depends on an attribute only known after apply).
  # IMPORTANT: if the naming pattern of the rg_* modules above changes,
  # update this list too so it doesn't drift out of sync.
  environment_resource_group_names = concat(
    [
      "rg-icsc-network-${var.environment}-${local.region_code_primary}",
      "rg-icsc-security-${var.environment}-${local.region_code_primary}",
      "rg-icsc-monitoring-${var.environment}-${local.region_code_primary}",
      "rg-icsc-backup-${var.environment}-${local.region_code_primary}",
    ],
    var.enable_dr ? [
      "rg-icsc-network-${var.environment}-${local.region_code_dr}",
      "rg-icsc-monitoring-${var.environment}-${local.region_code_dr}",
      "rg-icsc-backup-${var.environment}-${local.region_code_dr}",
    ] : []
  )

  environment_resource_group_scopes = [
    for name in local.environment_resource_group_names :
    "/subscriptions/${var.subscription_id}/resourceGroups/${name}"
  ]
}

resource "azurerm_role_assignment" "environment_admins" {
  for_each = var.environment_admins_group_object_id != null ? toset(local.environment_resource_group_scopes) : toset([])

  scope                = each.value
  role_definition_name = "Contributor"
  principal_id         = var.environment_admins_group_object_id
}

# Dedicated role on the Key Vault: with enable_rbac_authorization = true,
# the Contributor role above does NOT grant access to the data plane
# (secrets/keys), so without this the Key Vault is created but unusable.
resource "azurerm_role_assignment" "keyvault_admins" {
  count = var.keyvault_admins_group_object_id != null ? 1 : 0

  scope                = module.security_primary.key_vault_id
  role_definition_name = "Key Vault Administrator"
  principal_id         = var.keyvault_admins_group_object_id
}
