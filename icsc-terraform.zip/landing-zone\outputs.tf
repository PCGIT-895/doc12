output "primary_resource_groups" {
  value = {
    network    = module.rg_network_primary.name
    security   = module.rg_security_primary.name
    monitoring = module.rg_monitoring_primary.name
    backup     = module.rg_backup_primary.name
  }
}

output "dr_resource_groups" {
  value = var.enable_dr ? {
    network    = module.rg_network_dr[0].name
    monitoring = module.rg_monitoring_dr[0].name
    backup     = module.rg_backup_dr[0].name
  } : null
}

output "primary_hub_vnet_id" {
  value = module.networking_primary.hub_vnet_id
}

output "primary_farm_vnet_id" {
  value = module.networking_primary.farm_vnet_id
}

output "primary_ad_vnet_id" {
  value = module.networking_primary.ad_vnet_id
}

output "primary_dmz_vnet_id" {
  value = module.networking_primary.dmz_vnet_id
}

output "primary_vdi_vnet_id" {
  value = module.networking_primary.vdi_vnet_id
}

output "dr_hub_vnet_id" {
  value = var.enable_dr ? module.networking_dr[0].hub_vnet_id : null
}

output "dr_farm_vnet_id" {
  value = var.enable_dr ? module.networking_dr[0].farm_vnet_id : null
}

output "key_vault_uri" {
  value = module.security_primary.key_vault_uri
}

output "log_analytics_workspace_id_primary" {
  value = module.monitoring_primary.workspace_id
}

output "recovery_services_vault_primary" {
  value = module.backup_primary.vault_name
}

output "recovery_services_vault_dr" {
  value = var.enable_dr ? module.backup_dr[0].vault_name : null
}
