variable "subscription_id" {
  description = "ID of the ICSC project's single Azure subscription."
  type        = string
}

variable "primary_location" {
  description = "Primary region (Milan)."
  type        = string
  default     = "italynorth"
}

variable "dr_location" {
  description = "Disaster Recovery region (Frankfurt)."
  type        = string
  default     = "germanywestcentral"
}
