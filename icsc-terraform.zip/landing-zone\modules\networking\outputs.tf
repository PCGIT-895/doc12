output "hub_vnet_id" {
  value = azurerm_virtual_network.hub.id
}

output "hub_vnet_name" {
  value = azurerm_virtual_network.hub.name
}

output "ad_vnet_id" {
  value = azurerm_virtual_network.ad.id
}

output "dmz_vnet_id" {
  value = azurerm_virtual_network.dmz.id
}

output "farm_vnet_id" {
  value = azurerm_virtual_network.farm.id
}

output "farm_vnet_name" {
  value = azurerm_virtual_network.farm.name
}

output "vdi_vnet_id" {
  value = azurerm_virtual_network.vdi.id
}

output "farm_app_subnet_id" {
  value = azurerm_subnet.farm_app.id
}

output "farm_backend_subnet_id" {
  value = azurerm_subnet.farm_backend.id
}
