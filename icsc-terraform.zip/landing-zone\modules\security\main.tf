data "azurerm_client_config" "current" {}

# NOTE: the Key Vault name is unique at the GLOBAL Azure level. If
# "kv-icsc-<env>-<region>" already exists in another tenant, a suffix will
# need to be added (e.g. with a random_string resource) before the first apply.
resource "azurerm_key_vault" "this" {
  name                       = "kv-icsc-${var.environment}-${var.region_code}"
  location                   = var.location
  resource_group_name        = var.resource_group_name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  sku_name                   = "standard"
  enable_rbac_authorization  = true
  purge_protection_enabled   = true
  soft_delete_retention_days = 90
  tags                       = var.tags
}
