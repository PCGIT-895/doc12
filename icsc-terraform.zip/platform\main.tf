# ---------------------------------------------------------------------------
# Subscription-level Azure Policy guardrails.
#
# Origin: email from the project team (assessment phase, prior to the
# Azure Migrate deployment) proposing to enable these two minimum
# guardrails NOW, before deploying the Migration Project/appliance, so they
# apply at the fabric level regardless of how the resource is created:
#   1) Allowed Locations (Deny) = Italy North + Germany West Central
#   2) Secure transfer (HTTPS) + Minimum TLS = TLS1_2 on storage accounts
#
# CMK on Managed Disks/Storage Accounts is intentionally left OUT: the
# email itself states it should be enabled as an explicit milestone before
# the replicate/cutover phase (CMK cannot be applied retroactively), not
# during assessment. See TODO at the end of this file.
# ---------------------------------------------------------------------------

module "policy_guardrails" {
  source           = "./modules/policy"
  subscription_id  = var.subscription_id
  primary_location = var.primary_location
  dr_location      = var.dr_location
}

# ---------------------------------------------------------------------------
# TODO (explicit milestone, do NOT execute during this assessment phase):
# When the replicate/cutover phase starts, add here (or in a separate
# "policy_cmk" module) the policy assignments requiring:
#   - Managed Disks encrypted with Customer-Managed Keys
#   - Storage Accounts encrypted with Customer-Managed Keys
# and coordinate it as an explicit milestone in the Migration Hub
# (assessment -> replicate), as agreed with the client.
# ---------------------------------------------------------------------------
