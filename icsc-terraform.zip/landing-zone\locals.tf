locals {
  # "mi" = Milan (primary), "fr" = Frankfurt (DR) - same 2-letter codes the
  # client uses in its own documentation (e.g. "region MI/FR").
  region_code_primary = "mi"
  region_code_dr      = "fr"

  common_tags = merge(var.tags, {
    project     = "ICSC"
    environment = var.environment
    managed_by  = "terraform"
  })
}
