environment      = "staging"
subscription_id  = "REPLACE_WITH_SUBSCRIPTION_ID"
primary_location = "italynorth"
dr_location      = "germanywestcentral"

# DR disabled in staging, same reason as dev.
enable_dr = false

# Same criteria as dev.tfvars: its own /16 block (10.29.0.0/16), not
# overlapping with dev (10.28.0.0/16) or prod (10.27.0.0/16). Not defined
# by the client - VALIDATE before the first apply.
hub_cidr_primary  = "10.29.0.0/24"
ad_cidr_primary   = "10.29.8.0/25"
dmz_cidr_primary  = "10.29.8.128/25"
farm_cidr_primary = "10.29.128.0/22"
vdi_cidr_primary  = "10.29.132.0/22"

tags = {
  cost_center = "icsc-staging"
}

# ---------------------------------------------------------------------------
# RBAC (see landing-zone/variables.tf): fill in with the real Object ID of
# the Azure AD groups before the first "real" apply. While these lines
# stay commented/empty, no role assignment is created.
# ---------------------------------------------------------------------------
# environment_admins_group_object_id = "REPLACE_WITH_STAGING_ADMINS_GROUP_OBJECT_ID"
# keyvault_admins_group_object_id    = "REPLACE_WITH_SECURITY_GROUP_OBJECT_ID"
