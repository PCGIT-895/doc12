# ---------------------------------------------------------------------------
# Closes the TODO left in modules/monitoring/main.tf: connects the landing
# zone's main resources (Hub/Server Farm VNets, Key Vault, Recovery
# Services Vault) to their region's Log Analytics Workspace.
#
# category_group = "allLogs" is used (instead of listing individual
# categories) so that each diagnostic setting automatically captures every
# log category the resource type supports, without having to maintain
# resource-type-specific category lists.
# ---------------------------------------------------------------------------

resource "azurerm_monitor_diagnostic_setting" "hub_vnet" {
  name                       = "diag-${var.name_suffix}"
  target_resource_id         = var.hub_vnet_id
  log_analytics_workspace_id = var.workspace_id

  enabled_log {
    category_group = "allLogs"
  }
}

resource "azurerm_monitor_diagnostic_setting" "farm_vnet" {
  name                       = "diag-${var.name_suffix}"
  target_resource_id         = var.farm_vnet_id
  log_analytics_workspace_id = var.workspace_id

  enabled_log {
    category_group = "allLogs"
  }
}

resource "azurerm_monitor_diagnostic_setting" "key_vault" {
  count                      = var.has_key_vault ? 1 : 0
  name                       = "diag-${var.name_suffix}"
  target_resource_id         = var.key_vault_id
  log_analytics_workspace_id = var.workspace_id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

resource "azurerm_monitor_diagnostic_setting" "recovery_vault" {
  name                       = "diag-${var.name_suffix}"
  target_resource_id         = var.recovery_vault_id
  log_analytics_workspace_id = var.workspace_id

  enabled_log {
    category_group = "allLogs"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}
