resource "azurerm_resource_group" "this" {
  name     = var.name
  location = var.location
  tags     = var.tags

  # Extra safety net on top of provider.tf's
  # resource_group.prevent_deletion_if_contains_resources: that setting
  # only blocks deleting a Resource Group while it still has resources
  # inside. This blocks ANY destroy/replace of the Resource Group itself,
  # even an empty one, until someone deliberately removes this block first.
  lifecycle {
    prevent_destroy = true
  }
}
