environment      = "prod"
subscription_id  = "REPLACE_WITH_SUBSCRIPTION_ID"
primary_location = "italynorth"
dr_location      = "germanywestcentral"

# DR ENABLED in production: Milan -> Frankfurt replication confirmed in the
# client's technical documentation (ASR, Milan Primary / Frankfurt Secondary
# geo-sync) and in the official network HLD (see below).
enable_dr = true

# ---------------------------------------------------------------------------
# REAL address space agreed with the client (10.27.0.0/16), as documented in
# "ICSC - Azure Network Landing Zone" (HLD, v1.0, June 2026) - section 1.3
# "Network Address Space". These are not invented values: they reproduce
# exactly the addressing from the document (Hub 10.27.0.0/24, AD
# 10.27.8.0/25, DMZ 10.27.8.128/25, Server Farm 10.27.128.0/22, VDI Farm
# 10.27.132.0/22).
# ---------------------------------------------------------------------------

hub_cidr_primary  = "10.27.0.0/24"
ad_cidr_primary   = "10.27.8.0/25"
dmz_cidr_primary  = "10.27.8.128/25"
farm_cidr_primary = "10.27.128.0/22"
vdi_cidr_primary  = "10.27.132.0/22"

# DR (Frankfurt): Hub/AD/DMZ have their own CIDR (same document, "Disaster
# Recovery" section). Server Farm and VDI Farm are IDENTICAL to Milan on
# purpose: the DR model is "cold site" (servers keep their IP on failover,
# protected by Azure Site Recovery), so these two VNets are NEVER peered
# between regions.
hub_cidr_dr  = "10.27.16.0/24"
ad_cidr_dr   = "10.27.24.0/25"
dmz_cidr_dr  = "10.27.24.128/25"
farm_cidr_dr = "10.27.128.0/22"
vdi_cidr_dr  = "10.27.132.0/22"

tags = {
  cost_center = "icsc-prod"
}

# ---------------------------------------------------------------------------
# RBAC (see landing-zone/variables.tf): fill in with the real Object ID of
# the Azure AD groups before the first "real" apply. While these lines
# stay commented/empty, no role assignment is created.
# ---------------------------------------------------------------------------
# environment_admins_group_object_id = "REPLACE_WITH_PROD_ADMINS_GROUP_OBJECT_ID"
# keyvault_admins_group_object_id    = "REPLACE_WITH_SECURITY_GROUP_OBJECT_ID"
