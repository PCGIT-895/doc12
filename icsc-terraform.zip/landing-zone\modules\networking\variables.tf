variable "environment" {
  type = string
}

variable "region_code" {
  description = "Short region code: \"mi\" (Milan) or \"fr\" (Frankfurt)."
  type        = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

# ---------------------------------------------------------------------------
# CIDR per network "zone", following the segmentation from the client's
# official document "ICSC - Azure Network Landing Zone" (HLD, v1.0, June
# 2026):
#   Hub Network       -> Firewall (Fortinet FortiGate NVA) + VPN Gateway
#   Active Directory  -> Domain Controllers (extension of the on-prem AD)
#   DMZ               -> services exposed to the public network (reverse
#                        proxy, ADFS)
#   Server Farm       -> migrated application servers (lift-and-shift)
#   VDI Farm          -> Azure Virtual Desktop (host pools) - reserved, the
#                        actual AVD deployment is out of scope for this
#                        module (see README, point 6).
# ---------------------------------------------------------------------------

variable "hub_cidr" {
  description = "CIDR of this region's Hub VNet (perimeter firewall + VPN Gateway)."
  type        = string
}

variable "ad_cidr" {
  description = "CIDR of this region's Active Directory VNet (Domain Controllers)."
  type        = string
}

variable "dmz_cidr" {
  description = "CIDR of this region's DMZ VNet (services exposed to the Internet)."
  type        = string
}

variable "farm_cidr" {
  description = "CIDR of this region's Server Farm VNet (migrated application workloads)."
  type        = string
}

variable "vdi_cidr" {
  description = "CIDR of this region's VDI Farm VNet (reserved for Azure Virtual Desktop)."
  type        = string
}

variable "tags" {
  type    = map(string)
  default = {}
}
