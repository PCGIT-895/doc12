variable "subscription_id" {
  description = "ID of the subscription the policies are assigned to."
  type        = string
}

variable "primary_location" {
  type = string
}

variable "dr_location" {
  type = string
}
