variable "subscription_id" {
  description = "ID of the single Azure subscription for the ICSC project (same for dev/staging/prod)."
  type        = string
}

variable "environment" {
  description = "Environment for this deployment."
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

variable "primary_location" {
  description = "Primary region - Milan."
  type        = string
  default     = "italynorth"
}

variable "dr_location" {
  description = "Disaster Recovery region - Frankfurt."
  type        = string
  default     = "germanywestcentral"
}

variable "enable_dr" {
  description = "If true, also deploys the DR network topology in Frankfurt and the cross Hub<->Hub peering with Milan."
  type        = bool
  default     = false
}

# ---------------------------------------------------------------------------
# CIDR per network zone, following the segmentation from the client's
# official document "ICSC - Azure Network Landing Zone" (HLD, v1.0, June
# 2026): Hub (firewall+VPN) / AD (Domain Controllers) / DMZ / Server Farm /
# VDI Farm. See landing-zone/modules/networking for subnet details.
#
# For PRODUCTION these values reproduce the real address space agreed with
# the client (10.27.0.0/16). For DEV/STAGING the client has not yet defined
# its own range (the HLD only covers Production + DR), so distinct,
# non-overlapping /16 blocks are used here - to be validated with the client
# before the first apply (see README).
# ---------------------------------------------------------------------------

variable "hub_cidr_primary" {
  description = "CIDR of the Hub VNet in Milan (perimeter firewall + VPN Gateway)."
  type        = string
}

variable "ad_cidr_primary" {
  description = "CIDR of the Active Directory VNet in Milan."
  type        = string
}

variable "dmz_cidr_primary" {
  description = "CIDR of the DMZ VNet in Milan."
  type        = string
}

variable "farm_cidr_primary" {
  description = "CIDR of the Server Farm VNet in Milan."
  type        = string
}

variable "vdi_cidr_primary" {
  description = "CIDR of the VDI Farm VNet in Milan (reserved, AVD out of scope for this module)."
  type        = string
}

variable "hub_cidr_dr" {
  description = "CIDR of the Hub VNet in Frankfurt (only if enable_dr = true)."
  type        = string
  default     = null
}

variable "ad_cidr_dr" {
  description = "CIDR of the Active Directory VNet in Frankfurt (only if enable_dr = true)."
  type        = string
  default     = null
}

variable "dmz_cidr_dr" {
  description = "CIDR of the DMZ VNet in Frankfurt (only if enable_dr = true)."
  type        = string
  default     = null
}

variable "farm_cidr_dr" {
  description = <<-EOT
    CIDR of the Server Farm VNet in Frankfurt (only if enable_dr = true).
    Per the HLD, in the "cold site" DR model this block must be IDENTICAL
    to Milan's (DR servers keep their IP; replication happens via Azure
    Site Recovery at the VM level, not the network level). That is why this
    VNet is NEVER peered with Milan's (Azure does not allow peering between
    VNets with overlapping address space).
  EOT
  type        = string
  default     = null
}

variable "vdi_cidr_dr" {
  description = "CIDR of the VDI Farm VNet in Frankfurt (only if enable_dr = true). Same 'cold site' criteria as farm_cidr_dr."
  type        = string
  default     = null
}

variable "tags" {
  description = "Additional environment-specific tags."
  type        = map(string)
  default     = {}
}

# ---------------------------------------------------------------------------
# RBAC: Azure AD (Entra ID) groups that will administer this environment.
#
# The "resource groups within a single subscription" model (confirmed by
# the client's email) separates resources logically, but does not by
# itself separate who can administer them: without these role assignments,
# any identity with a subscription-level role (needed to apply platform/)
# would have the same access to dev, staging and prod.
#
# Both variables are intentionally optional (default null): as long as the
# client has not confirmed the Object ID of its Azure AD groups, the code
# still applies without creating any role assignment (identical behavior to
# before). Once those IDs are available, fill them in the environment's
# .tfvars and the access guardrails become effective.
# ---------------------------------------------------------------------------

variable "environment_admins_group_object_id" {
  description = <<-EOT
    Object ID of the Azure AD group that will administer the resources of
    THIS environment (gets the Contributor role, scoped only to this
    environment's Resource Groups - not at subscription level). Use a
    different group per environment (e.g. "ICSC-Admins-Dev",
    "ICSC-Admins-Prod") so management access is genuinely separated between
    dev/staging/prod.
    null = no role assignment is created (default, until the groups are
    confirmed with the client).
  EOT
  type        = string
  default     = null
}

variable "keyvault_admins_group_object_id" {
  description = <<-EOT
    Object ID of the security team's Azure AD group, with administration
    permissions over this environment's Key Vault ("Key Vault
    Administrator" role). Managed separately from the group above on
    purpose: the Key Vault uses RBAC authorization (enable_rbac_authorization
    = true), whose data plane (reading/writing secrets) is NOT covered by
    the general-management Contributor role - it requires a dedicated Key
    Vault role, and in banking this is usually a different team (segregation
    of duties) from whoever administers the rest of the environment's
    resources.
    null = no role assignment is created (default).
  EOT
  type        = string
  default     = null
}
