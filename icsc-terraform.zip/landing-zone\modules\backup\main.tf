# Recovery Services Vault: used both for VM backup and as the base for
# Azure Site Recovery (ASR) to/from Frankfurt, as mentioned in the client's
# technical documentation ("Azure Site Recovery (ASR) in Frankfurt").
resource "azurerm_recovery_services_vault" "this" {
  name                = "rsv-icsc-${var.environment}-${var.region_code}"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "Standard"
  soft_delete_enabled = true
  tags                = var.tags
}

resource "azurerm_backup_policy_vm" "daily" {
  name                = "policy-vm-daily-${var.environment}-${var.region_code}"
  resource_group_name = var.resource_group_name
  recovery_vault_name = azurerm_recovery_services_vault.this.name

  backup {
    frequency = "Daily"
    time      = "23:00"
  }

  retention_daily {
    count = 30
  }
}
