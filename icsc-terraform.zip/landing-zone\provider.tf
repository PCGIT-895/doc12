terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
  }

  # Remote state backend - fill in before the first `terraform init`.
  # Use a different key per environment, e.g. via -backend-config at init time:
  #   terraform init -backend-config="key=landingzone-dev.tfstate"
  backend "azurerm" {
    # resource_group_name  = "rg-icsc-tfstate"
    # storage_account_name = "sticsctfstateXXXX"
    # container_name       = "tfstate"
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy    = false
      recover_soft_deleted_key_vaults = true
    }
    resource_group {
      prevent_deletion_if_contains_resources = true
    }
  }

  subscription_id = var.subscription_id
}
