# Terraform - Azure Landing Zone ICSC

Code generated and enriched from the project's official documentation,
meeting minutes, and emails from the project team (client) confirming
architecture decisions. See "Decisions and their origin" below.

**Note on discarded sources**: GENERIC template documents were identified
(region "West Europe/North Europe", region codes like "eus/weu", budgets
and AKS/Cosmos DB architecture) that do not match this project's actual
scope. They were not used as a data source: priority was always given to
the versioned, signed technical documentation from the project team.

## Structure

```
platform/        -> SUBSCRIPTION-level Azure Policy guardrails.
                     Applied ONCE (not per environment).

landing-zone/     -> Resource Groups, networks (Hub / Active Directory / DMZ /
                     Server Farm / VDI Farm), Key Vault, Log Analytics and
                     Recovery Services Vault, with diagnostic settings to
                     Log Analytics.
                     Applied ONCE PER ENVIRONMENT (dev / staging / prod),
                     all against the SAME subscription.
```

## Decisions and their origin

| Decision | Origin | Where it applies |
|---|---|---|
| Primary region = Italy North (Milan) | Repeated technical documentation (Roadmap, Technical Annex, network HLD) | `primary_location` |
| DR = Germany West Central (Frankfurt) | Operational resilience and security document, technical Azure guidelines annex, official network HLD, meeting minutes | `dr_location`, enabled only in `prod.tfvars` |
| Single subscription | Client email: "we will only have one subscription available" | Same `subscription_id` in all 3 tfvars |
| Resource Groups model (no Management Groups / multi-sub) | Client email: "the division of resources, hub and spoke, will need to be managed through resource groups" / "different resource groups within a single subscription, with different VNets" | Entire `landing-zone/` structure |
| Policy guardrails in the assessment phase (Allowed Locations + Secure Transfer/TLS1.2), CMK deferred to the replicate milestone | Project team email about the Azure Migrate deployment | `platform/` |
| Real address space = `10.27.0.0/16`, segmented into 5 VNets (Hub / AD / DMZ / Server Farm / VDI Farm) | Official HLD "Azure Network Landing Zone" v1.0 (June 2026), section 1.3 "Network Address Space" | `landing-zone/modules/networking`, `environments/prod.tfvars` |
| Perimeter firewall = Fortinet FortiGate NVA (Active-Active HA cluster, 3x `Standard_F4s_v2` from Marketplace), NOT native Azure Firewall | Same HLD (section 1.4.1 "Fortinet Fortigate Architecture"); confirmed in the VM inventory with Azure sizing and in the project's RACI Matrix | `snet-fw-public-*` / `snet-fw-private-*` subnets in `modules/networking` (NOT reserved names, unlike `AzureFirewallSubnet`) |
| DR in "cold site" mode: Server Farm and VDI Farm share the SAME address space in Milan and Frankfurt (replication via Azure Site Recovery at the VM level, not network level); only Hub/AD/DMZ have their own CIDR per region and are peered to each other | Same HLD, section 1.6 "Disaster Recovery" | `modules/networking` (no spoke-to-spoke cross-region peering), `prod.tfvars` (`farm_cidr_dr` = `farm_cidr_primary`) |
| Domain Controllers in a dedicated VNet, internal DNS resolver via `168.63.129.16`; dedicated DMZ for exposed services (reverse proxy / ADFS) | Same HLD, section 1.4 "Hub Network" | `ad` and `dmz` VNets in `modules/networking` |
| CMK via Key Vault (HSM), AES-256 encryption, backups with Immutability (WORM) + Soft Delete, SQL MI with Auto-Failover Groups | Project's operational resilience and security document | `modules/security` (Key Vault), `modules/backup` (Recovery Services Vault) |
| Client (Banking) vs. Vendor RACI per phase (Governance/IAM, Foundation IaC, Security & Net, Data Protection, Business Continuity, Audit) | Project RACI Matrix | See the executive report delivered alongside this code |

## Assumptions I had to set myself (not explicit in the documentation)

Since I was asked to generate the code without asking questions, these are
the points where I had to decide on my own and that **should be reviewed
before the first apply**:

1. **Dev/staging CIDR.** The official HLD only defines address space for
   Production + DR (`10.27.0.0/16`). Dev/staging are not covered by any
   client document. Distinct, non-overlapping `/16` blocks were used,
   mirroring the same internal segmentation as prod:
   - dev: `10.28.0.0/16` (Hub `10.28.0.0/24`, AD `10.28.8.0/25`, DMZ
     `10.28.8.128/25`, Server Farm `10.28.128.0/22`, VDI `10.28.132.0/22`)
   - staging: `10.29.0.0/16` (same breakdown, base `10.29.x.x`)
   - prod Milan / Frankfurt: see table above (`10.27.0.0/16`, real HLD
     values).
   **The dev/staging ranges must be validated with the client/network
   team** before deploying (the prod ones are already documented and
   should not require changes, barring a review of a newer HLD version).

2. **DR only in prod.** `enable_dr = true` is active only in
   `prod.tfvars`. If dev/staging also need DR, change it there.

3. **Built-in policy definition GUIDs** in
   `platform/modules/policy/main.tf` are Azure's usual public
   identifiers, but I could not verify them against the real
   subscription. Before the first `apply`, confirm them with
   `az policy definition list`.

4. **Key Vault names** (`kv-icsc-<env>-<region>`) are deterministic; Key
   Vault requires a globally unique name across Azure. If there is a
   collision, a suffix needs to be added.

5. **State backend** left as a placeholder (empty `backend "azurerm"`
   block) in both `provider.tf` files. The state storage account needs to
   be created (outside this code, so it does not depend circularly on
   itself) and the values filled in before `terraform init`.

6. **Scope:** this code covers the platform/Landing Zone layer (Resource
   Groups, networks, Key Vault, Log Analytics, Recovery Services Vault).
   The `farm` and `vdi` VNets are reserved and sized per the HLD, but this
   **does NOT include** the migrated VMs (Azure Migrate), the FortiGate VM
   deployment itself, or AVD (host pools/session hosts) — these would be
   built as additional modules once this base is deployed.

7. **CMK on disks/storage** is deliberately NOT included (see TODO in
   `platform/main.tf`) — per the email, it should be enabled as an
   explicit milestone right before the replicate phase, not now.

8. **NSG rules.** NSGs were added per zone (AD/DMZ/Server Farm) but with
   minimal rules (only DMZ has an explicit HTTPS inbound rule, as a
   placeholder). The detailed rules (exact sources/ports) must be
   confirmed against the client's network access census and on-premises
   firewall rules before applying for real.

9. **Diagram with "Subscription HUB" / "Subscription SPOKE".** One of the
   project's older diagrams shows two separate subscriptions (HUB/SPOKE),
   which appears to be a generic Microsoft reference template rather than
   an ICSC-specific decision (it contradicts the client's email about a
   single subscription, which is more specific and more recent). The
   single-subscription model has been kept, but **explicit
   reconfirmation with the client is recommended**.

10. **No Key Vault in the DR region** (mirrors the code's original
    design). If failover to Frankfurt needs access to secrets/CMK without
    depending on Milan staying available, an additional Key Vault in
    `germanywestcentral` (or secret replication/geo-restore) should be
    evaluated as a future improvement.

11. **Environment and Key Vault RBAC.** The "resource groups within a
    single subscription" model separates resources logically, but does
    not by itself separate who can administer them. Two optional
    per-environment variables were added
    (`environment_admins_group_object_id`,
    `keyvault_admins_group_object_id`, see `landing-zone/variables.tf`)
    that create `azurerm_role_assignment` resources using the Object ID of
    an Azure AD group: `Contributor` over that environment's Resource
    Groups, and `Key Vault Administrator` over its Key Vault (a separate
    role because the Key Vault uses `enable_rbac_authorization = true`,
    whose data plane is not covered by the general `Contributor` role).
    As long as those variables stay `null` (the default, and how they are
    commented out in the `.tfvars` files), no role assignment is created.
    **These Azure AD groups need to be created and their Object ID filled
    in before the first real apply.**

## How to run it

```bash
# 1) Subscription guardrails (once)
cd platform
cp terraform.tfvars.example terraform.tfvars   # and fill in the real subscription_id
terraform init
terraform plan
terraform apply

# 2) Landing zone, per environment
cd ../landing-zone
terraform init -backend-config="key=landingzone-dev.tfstate"
terraform plan  -var-file="environments/dev.tfvars"
terraform apply -var-file="environments/dev.tfvars"

# repeat with staging.tfvars / prod.tfvars, using a different backend key
# for each one, since they share the same subscription but must have
# independent states.
```

## Pending validation with the client/team before deploying for real

- Dev/staging CIDR ranges (point 1 above); prod's are already documented
  in the official HLD.
- Confirmation of policy GUIDs (point 3).
- Detailed per-zone NSG rules (point 8).
- Single-subscription model vs. the old HUB/SPOKE diagram (point 9).
- Whether AVD/Azure Migrate/FortiGate should live in their own RGs within
  this same scheme or in a different subscription/structure.
