output "allowed_locations_assignment_id" {
  value = azurerm_subscription_policy_assignment.allowed_locations.id
}

output "storage_secure_transfer_assignment_id" {
  value = azurerm_subscription_policy_assignment.storage_secure_transfer.id
}

output "storage_min_tls_assignment_id" {
  value = azurerm_subscription_policy_assignment.storage_min_tls.id
}
