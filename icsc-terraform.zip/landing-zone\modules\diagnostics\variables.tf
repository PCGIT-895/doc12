variable "workspace_id" {
  description = "ID of the destination Log Analytics Workspace."
  type        = string
}

variable "name_suffix" {
  description = "Suffix (environment-region_code) for naming the diagnostic settings."
  type        = string
}

variable "hub_vnet_id" {
  type = string
}

variable "farm_vnet_id" {
  type = string
}

variable "key_vault_id" {
  description = "ID of the Key Vault to diagnose. null if this region has no Key Vault of its own."
  type        = string
  default     = null
}

variable "has_key_vault" {
  description = <<-EOT
    Whether this region has a Key Vault to diagnose (true for the primary
    region, false for DR). This is a plain boolean known at plan time on
    purpose - do NOT replace the key_vault resource's count with
    `key_vault_id != null`: key_vault_id comes from a Key Vault that may
    not exist yet on the first apply, so its value is unknown until apply,
    and Terraform cannot size a `count` from an unknown value ("Invalid
    count argument").
  EOT
  type        = bool
  default     = true
}

variable "recovery_vault_id" {
  type = string
}
