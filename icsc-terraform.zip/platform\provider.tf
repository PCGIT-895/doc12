terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
  }

  # Remote state backend - fill in before the first `terraform init`.
  # A dedicated storage account is recommended (outside this same code) so
  # it does not depend on a resource that this very Terraform manages.
  backend "azurerm" {
    # resource_group_name  = "rg-icsc-tfstate"
    # storage_account_name = "sticsctfstateXXXX"
    # container_name       = "tfstate"
    # key                  = "platform.tfstate"
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}
