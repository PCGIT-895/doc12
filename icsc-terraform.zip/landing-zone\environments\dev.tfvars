environment      = "dev"
subscription_id  = "16eaf4c0-10f5-40ad-8cc6-d93f09632ae1"
primary_location = "italynorth"
dr_location      = "germanywestcentral"

# DR disabled in dev: the cost/complexity of Frankfurt is not justified for
# a development environment. Enable it here if the team decides otherwise.
enable_dr = false

# ---------------------------------------------------------------------------
# The official network HLD ("ICSC - Azure Network Landing Zone", June 2026)
# only defines address space for Production + DR (10.27.0.0/16). The client
# has not yet fixed a range of its own for dev/staging. A distinct,
# non-overlapping /16 block is used here (10.28.0.0/16), mirroring the same
# internal segmentation as prod.tfvars, so it is deployable in isolation.
# VALIDATE with the client/network team before the first apply.
# ---------------------------------------------------------------------------

hub_cidr_primary  = "10.28.0.0/24"
ad_cidr_primary   = "10.28.8.0/25"
dmz_cidr_primary  = "10.28.8.128/25"
farm_cidr_primary = "10.28.128.0/22"
vdi_cidr_primary  = "10.28.132.0/22"

tags = {
  cost_center = "icsc-dev"
}

# ---------------------------------------------------------------------------
# RBAC (see landing-zone/variables.tf): fill in with the real Object ID of
# the Azure AD groups before the first "real" apply. While these lines
# stay commented/empty, no role assignment is created.
# ---------------------------------------------------------------------------
# environment_admins_group_object_id = "REPLACE_WITH_DEV_ADMINS_GROUP_OBJECT_ID"
# keyvault_admins_group_object_id    = "REPLACE_WITH_SECURITY_GROUP_OBJECT_ID"
