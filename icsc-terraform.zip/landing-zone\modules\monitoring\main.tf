resource "azurerm_log_analytics_workspace" "this" {
  name                = "log-icsc-${var.environment}-${var.region_code}"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 90
  tags                = var.tags
}

# The diagnostic settings connecting VNets/Key Vault/Recovery Services Vault
# to this workspace are defined in ../diagnostics (see landing-zone/main.tf).
